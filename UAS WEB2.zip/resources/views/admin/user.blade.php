@extends('layouts.layout')
@section('content')
<div class="table-responsive">
    <?php if(count($errors)>0) : ?>
        <script type="text/javascript">
            $(document).ready(function(){ alert('gagal menginput data')})
            </script>
            <?php endif;?>
            <button class="btn btn-succes" data-toggle="modal" data-target="#modaltambah">Tambah Data</button>
            <hr>
            <div class="row">
    </div>
    <table id="tbl_siswa" class="compact table-bordered table-striped table-hover" style="width:100%">
<thead>
    <tr>
        <th height="50">No</th>
        <th>Nomor Induk</th>
        <th>Nama</th>
        <th>Aksi</th>
    </tr>
</thead>
<tbody>
    <?php $no=0; foreach ($user as $key =>$value):
    $no++; ?>
    <tr>
        <td>{{$no}}</td>
        <td>{{$value->name}}</td>
        <td>{{$value->email}}</td>

        <td style="width:15%"><span> <a class="btn btn-warning" href="form/edit/{{$value->noinduk}}"></a>
        <form onsubmit="return confirm('Delete this usernpermanently?')" class="d-inline"
        action="{{route('user.destroy', [$value->id])}}" method="POST">@csrf<input type="hidden"
        name="method" value="DELETE">
        <input type="submit" value="Delete" class="btn btn-danger btn-sm"> </form>
    </span></td>

    </tr>
    <?php endforeach; ?>
</tbody>
</table>
    </div>
    <script type="text/javascript"> $(document).ready(function(){
        $('#user').DataTable({
            scrollx: false,});
            </script>