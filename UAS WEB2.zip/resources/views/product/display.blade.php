<div>
Data yang dikirim dari controller adalah: {{$products}}
</div>